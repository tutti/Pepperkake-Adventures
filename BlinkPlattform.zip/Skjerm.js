Skjerm = function() {
    
}

Skjerm.prototype.legg_til_plattform = function(plattform) {
    
}