<!DOCTYPE html>
<html>
    <head>
        <title>Pepperkake Adventures</title>
        <link rel="stylesheet" href="stil.css" />
        <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <?php require "brett.php"; ?>
        <script src="Kontroll.js"></script>
        <script src="Enhet.js"></script>
        <script src="SpillerKontroll.js"></script>
        <script src="Spiller.js"></script>
        <script src="Plattform.js"></script>
        <script src="BlinkPlattform.js"></script>
        <script src="HeisPlattform.js"></script>
        <script src="Brett.js"></script>
        <script src="Spill.js"></script>
        <script src="pepperkake.js"></script>
    </head>
    <body>
        <div id="spillvindu"></div>
    </body>
</html>